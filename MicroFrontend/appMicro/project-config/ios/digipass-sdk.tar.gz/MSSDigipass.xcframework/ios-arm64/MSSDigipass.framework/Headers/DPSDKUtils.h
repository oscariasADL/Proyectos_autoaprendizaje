//////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) since 1999. VASCO DATA SECURITY
//  All rights reserved. http://www.vasco.com
//
//////////////////////////////////////////////////////////////////////////////

#ifndef DPSDKUtils_H
#define DPSDKUtils_H

#include "DPSDKConstants.h"
#include <stddef.h>

vds_bool digipass_isFlagSet(vds_int32 value, vds_int32 mask);

vds_int32 digipass_getCurrentTimeInSeconds(void);

void digipass_resetBytesArray(vds_byte* array, vds_int32 arrayLength);

vds_bool digipass_isCharsArrayNullOrEmpty(const vds_ascii* charArray);

vds_bool digipass_isBytesArrayNullOrEmpty(const vds_byte* array, vds_int32 arrayLength);

vds_bool digipass_isHexaDecimal(const vds_ascii *str);

vds_int32 digipass_bytesToHexa(const vds_byte *input, vds_int32 inputLength, vds_ascii *output);

vds_int32 digipass_hexaToBytesEx(const vds_ascii *input, vds_byte *output, vds_int32 *outputLength, vds_int32 offset);

vds_int32 digipass_hexaToBytes(const vds_ascii *input, vds_byte *output, vds_int32 *outputLength);

vds_int32 digipass_hexaToByte(vds_ascii hexa);

#endif
