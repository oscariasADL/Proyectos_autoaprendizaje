
#ifndef CREDENTIALSDATA_H_
#define CREDENTIALSDATA_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else 
  #define EXPORT_DLL   
#endif  

#include <string>

namespace com
{
namespace vasco
{
namespace message
{
namespace client
{

class CredentialsData
{

private:

    int version;
    std::string registrationIdentifier;
    std::string authorizationCode;
    std::string activationPassword;
    std::string userIdentifier;

public:

    /**
     * Constructor
     */
    EXPORT_DLL CredentialsData();

    /**
     * Constructs a CredentialData object.
     * @param version The version used for the message
     * @param registrationIdentifier The registration identifier
     * @param authorizationCode The authorization code
     * @param activationPassword The activation password
     * @param userIdentifier The user identifier
     */
    EXPORT_DLL CredentialsData(int version, std::string registrationIdentifier, std::string authorizationCode, std::string activationPassword,
                               std::string userIdentifier);

    /**
     * Gets the version.
     * @return the version of the message.
     */
    EXPORT_DLL int getVersion();

    /**
     * Gets the registration identifier.
     * @return the registrationIdentifier.
     */
    EXPORT_DLL std::string getRegistrationIdentifier();

    /**
     * Gets the authorization code.
     * @return the authorizationCode.
     */
    EXPORT_DLL std::string getAuthorizationCode();

    /**
     * Gets the activation password.
     * @return the activationPassword.
     */
    EXPORT_DLL std::string getActivationPassword();

    /**
     * Gets the user identifier.
     * @return the userIdentifier.
     */
    EXPORT_DLL std::string getUserIdentifier();

};

} /* namespace client */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* CREDENTIALSDATA_H_ */
