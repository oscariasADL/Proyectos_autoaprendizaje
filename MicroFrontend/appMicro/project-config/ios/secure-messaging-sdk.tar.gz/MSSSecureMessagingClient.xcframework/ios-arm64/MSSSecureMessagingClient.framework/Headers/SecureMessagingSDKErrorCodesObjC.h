#import <Foundation/Foundation.h>

NS_REFINED_FOR_SWIFT
@interface SecureMessagingSDKErrorCodesObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/** An internal error occurred. */
@property(class, nonatomic, readonly) NSInteger internalError;

/** The credentials message is invalid. */
@property(class, nonatomic, readonly) NSInteger credentialsMessageInvalid;

/** The credentials message is empty or null. */
@property(class, nonatomic, readonly) NSInteger credentialsMessageNullOrEmpty;

/** The formatted text list is null or empty. */
@property(class, nonatomic, readonly) NSInteger formattedTextsNullOrEmpty;

/** The clear text of formatted text is null or empty. */
@property(class, nonatomic, readonly) NSInteger formattedTextClearTextNullOrEmpty;

/**
 * Formatted text alignment is invalid.
 * Formatted text alignment must be
 * {@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentDefault}, {@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentLeft},
 * {@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentCenter}, {@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentRight}.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextAlignmentInvalid;

/**
 * Formatted text color is invalid.
 * Formatted text color must be {@link SecureMessagingSDKConstantsObjC#formattedTextColorDefault},
 * {@link SecureMessagingSDKConstantsObjC#formattedTextColorRed}, {@link SecureMessagingSDKConstantsObjC#formattedTextColorGreen},
 * {@link SecureMessagingSDKConstantsObjC#formattedTextColorBlue}, {@link SecureMessagingSDKConstantsObjC#formattedTextColorBlack}.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextColorInvalid;

/** The message body is invalid, the return code value is. */
@property(class, nonatomic, readonly) NSInteger messageBodyInvalid;

/** The message body is empty or null. */
@property(class, nonatomic, readonly) NSInteger messageBodyNullOrEmpty;

/** The message body is not an hexadecimal value. */
@property(class, nonatomic, readonly) NSInteger messageBodyIncorrectFormat;

/** The message body length is not even. */
@property(class, nonatomic, readonly) NSInteger messageBodyLengthNotEven;

/** The message body length is too short. */
@property(class, nonatomic, readonly) NSInteger messageBodyTooShort;

/** A character is not supported by the current font table. */
@property(class, nonatomic, readonly) NSInteger fontTableUnsupportedCharacter;

/** The font table indexes provided in incorrect order. */
@property(class, nonatomic, readonly) NSInteger fontTableIndexInvalid;

/**
 * @deprecated
 *
 * Font table index is not supported.
 * This error code is not used anymore and is there for backward compatibility.
 */
@property(class, nonatomic, readonly) NSInteger fontTableIndexNotSupported;

/** The font table indexes provided in incorrect order. */
@property(class, nonatomic, readonly) NSInteger fontTableIndexInvalidMappingOrder;

/** All provided font table indexes are empty, there should be at least one correct font table index provided. */
@property(class, nonatomic, readonly) NSInteger fontTableIndexesEmptyMapping;

@end
