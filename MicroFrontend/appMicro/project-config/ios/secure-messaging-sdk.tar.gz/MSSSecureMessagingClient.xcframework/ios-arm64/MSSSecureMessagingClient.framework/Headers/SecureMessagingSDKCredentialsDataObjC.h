#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

NS_REFINED_FOR_SWIFT
/**
 * Object contening information about the credentials
 */
@interface SecureMessagingSDKCredentialsDataObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Gets the version.
 * @return the version of the message.
 */
@property(nonatomic, readonly) NSInteger version;

/**
 * Gets the registration identifier.
 * @return the registrationIdentifier.
 */
@property(nonatomic, readonly) NSString *registrationIdentifier;

/**
 * Gets the authorization code.
 * @return the authorizationCode.
 */
@property(nonatomic, readonly) NSString *authorizationCode;

/**
 * Gets the activation password.
 * @return the activationPassword.
 */
@property(nonatomic, readonly) NSString *activationPassword;

/**
 * Gets the user identifier.
 * @return the userIdentifier.
 */
@property(nonatomic, readonly) NSString *userIdentifier;

@end

NS_ASSUME_NONNULL_END
