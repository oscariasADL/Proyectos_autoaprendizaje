#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

NS_REFINED_FOR_SWIFT
/**
 * Object contening information about the deactivation
 */
@interface SecureMessagingSDKDeactivationDataObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Returns the bodyType of the Deactivation request message.
 * @return the bodyType of the Deactivation Request message.
 */
@property(nonatomic, readonly) NSInteger bodyType;

/**
 * Returns the sequence number.
 * @return the sequence number
 */
@property(nonatomic, readonly) NSInteger sequenceNumber;

@end

NS_ASSUME_NONNULL_END
