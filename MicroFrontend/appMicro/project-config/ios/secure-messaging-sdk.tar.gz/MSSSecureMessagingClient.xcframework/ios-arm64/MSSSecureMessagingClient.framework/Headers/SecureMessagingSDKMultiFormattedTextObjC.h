#import <Foundation/Foundation.h>

@class SecureMessagingSDKFormattedTextObjC;

NS_REFINED_FOR_SWIFT
@interface SecureMessagingSDKMultiFormattedTextObjC : NSObject

+ (instancetype _Nonnull)new NS_UNAVAILABLE;
- (instancetype _Nonnull)init NS_UNAVAILABLE;

/**
 * Returns the text without any formatting.
 *
 * @return the clear text
 */
@property(nonatomic, readonly, copy, nonnull) NSString *clearText;

/**
 * Returns the text with formatting.
 *
 * @return the encoded text
 */
@property(nonatomic, readonly, copy, nonnull) NSString *encodedText;

/**
 * Returns the vector of formatted texts (See {@link SecureMessagingSDKFormattedTextObjC})
 *
 * @return vector of formatted texts
 */
@property(nonatomic, readonly, copy, nonnull) NSArray<SecureMessagingSDKFormattedTextObjC *> *formattedTextList;

/**
 * Returns the alignment of the text.
 * <ul>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentDefault}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentLeft}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentCenter}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentRight}</li>
 * </ul>
 * @return The alignment of the text
 */
@property(nonatomic, readonly, assign) char textAlignment;

/**
 * Returns the font table index of the text.
 * <ul>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexIso8859_15}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexKatakana}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexCentralAndEastEurope}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexGreek}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexTurkish}</li>
 * </ul>
 * @return The font table index of the text
 */
@property(nonatomic, readonly, assign) NSInteger fontTableIndex;

@end
