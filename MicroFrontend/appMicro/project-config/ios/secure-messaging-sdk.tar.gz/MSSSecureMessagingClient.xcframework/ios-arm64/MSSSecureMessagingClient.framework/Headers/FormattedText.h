
#ifndef FORMATEDTEXT_H_
#define FORMATEDTEXT_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else 
  #define EXPORT_DLL   
#endif  

#include <MSSSecureMessagingClient/SecureMessagingSDKException.h>

#include <string>

namespace com
{
namespace vasco
{
namespace message
{
namespace model
{

class FormattedText
{

private:

    std::string clearText;

    std::string encodedText;

    bool Bold;

    bool Italic;

    bool Inverse;

    char color;

    char textAlignment;

    int fontTableIndex;

    void init(std::string text, bool isBold, bool isItalic, bool isInverse, char color, char textAlignment, int fontTableIndex);

    void setBold(bool isBold);

    void setItalic(bool isItalic);

    void setInverse(bool isInverse);

    void setColor(char color);

    void setTextAlignment(char textAlignment);

    void setClearText(std::string clearText);

    void setEncodedText(std::string encodedText);

    void setFontTableIndex(int fontTableIndex);

    void appendFormattingChars(std::string& formattedText);

public:

    /**
     * Constructs a formatted text with empty text, default color, default text alignment, and default encoding (ISO-8859-15).
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
     * </ul>
     */
    EXPORT_DLL FormattedText();
    
    /**
     * Copy constructor
     */
    EXPORT_DLL FormattedText(const FormattedText& other);
    
    EXPORT_DLL FormattedText& operator=(const FormattedText& other);
    
    EXPORT_DLL ~FormattedText();

    /**
     * Constructs a formatted text.
     * @param text The text
     * @param isBold True if the text is in bold
     * @param isItalic True if the text is in italic
     * @param isInverse True if the text is inversed
     * @param color The color of the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_DEFAULT},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_RED}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_GREEN},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLUE}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLACK})
     * @param textAlignment The text alignment of the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT}, {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT})
     * @param fontTableIndex The font table index used for encoding the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA}, {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_GREEK}, {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_TURKISH})
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
     *  <li>{@link com::vasco::message::constants::FONT_TABLE_INDEX_INVALID} if the font table index is invalid</li>
     *  <li>{@link com::vasco::message::constants::FONT_TABLE_UNSUPPORTED_CHARACTER} if a character is not supported by the current font table</li>
     * </ul>
     */
    EXPORT_DLL FormattedText(std::string text, bool isBold, bool isItalic, bool isInverse, char color, char textAlignment, int fontTableIndex);

    /**
     * Constructs a formatted text with default font table index (first one passed to #setCustomFontTablesIndexes or ISO-8859-15
     * when custom available font tables indexes were not set).
     * @param text The text
     * @param isBold True if the text is in bold
     * @param isItalic True if the text is in italic
     * @param isInverse True if the text is inversed
     * @param color The color of the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_DEFAULT},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_RED}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_GREEN},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLUE}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLACK})
     * @param textAlignment The text alignment of the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT}, {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT})
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
     * </ul>
     */
    EXPORT_DLL FormattedText(std::string text, bool isBold, bool isItalic, bool isInverse, char color, char textAlignment) ;

    /**
     * Constructs a formatted text with default text alignment, and default font table index
     * (first one passed to #setCustomFontTablesIndexes or ISO-8859-15 when custom available font tables indexes were not set).
     * @param text The text
     * @param color The color of the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_DEFAULT},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_RED}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_GREEN},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLUE}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLACK})
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
     * </ul>
     */
    EXPORT_DLL FormattedText(std::string text, char color);

    /**
     * Constructs a formatted text with default color, and default text alignment.
     * @param text The text
     * @param fontTableIndex The font table index used for encoding the text (See {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA}, {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE},
     * {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_TURKISH})
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FONT_TABLE_INDEX_INVALID} if the font table index is invalid</li>
     *  <li>{@link com::vasco::message::constants::FONT_TABLE_UNSUPPORTED_CHARACTER} if a character is not supported by the current font table</li>
     * </ul>
     */
    EXPORT_DLL FormattedText(std::string text, int fontTableIndex) ;

    /**
     * Constructs a formatted text with default color, default text alignment, and default font table index
     * (first one passed to #setCustomFontTablesIndexes or ISO-8859-15 when custom available font tables indexes were not set).
     * @param text The text
     * @throws SecureMessagingSDKException
     */
    EXPORT_DLL explicit FormattedText(std::string text);

    /**
     * Parse an formatted text as a formatted text object.
     * @param text The text to parse
     * @param fontTableIndex The font table index used for encoding the text
     * @return The formatted text object
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
     *  <li>{@link com::vasco::message::constants::MESSAGE_BODY_INVALID} if the text is invalid</li>
     *  <li>{@link com::vasco::message::constants::FONT_TABLE_INDEX_INVALID} if the font table index is invalid</li>
     * </ul>
     */
    EXPORT_DLL static FormattedText parseText(std::string text, int fontTableIndex);


    /**
     * Returns the formatted text as a string.
     */
    EXPORT_DLL std::string toString();

    EXPORT_DLL std::string toStringMultiFormattedText();
    

    /**
     * Returns the text without any formatting.
     * @return the clear text
     */
    EXPORT_DLL std::string getClearText() const;

    /**
     * Returns the text with formatting.
     * @return the encoded text
     */
    EXPORT_DLL std::string getEncodedText() const;

    /**
     * Returns if the text is in bold or not.
     * @return True if the text is in bold
     */
    EXPORT_DLL bool isBold() const;

    /**
     * Returns if the text is in italic or not.
     * @return True if the text is in italic
     */
    EXPORT_DLL bool isItalic() const;

    /**
     * Returns if the text is inversed or not.
     * @return True if the text is inversed
     */
    EXPORT_DLL bool isInverse() const;

    /**
     * Returns the color of the text.
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_DEFAULT}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_RED}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_GREEN}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLUE}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLACK}</li>
     * </ul>
     * @return The color of the text
     */
    EXPORT_DLL char getColor() const;

    /**
     * Returns the alignment of the text.
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT}</li>
     * </ul>
     * @return The alignment of the text
     */
    EXPORT_DLL char getTextAlignment() const;

    /**
     * Returns the font table index of the text.
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_GREEK}</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_TURKISH}</li>
     * </ul>
     * @return The font table index of the text
     */
    EXPORT_DLL int getFontTableIndex() const;

};

} /* namespace model */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* FORMATEDTEXT_H_ */
