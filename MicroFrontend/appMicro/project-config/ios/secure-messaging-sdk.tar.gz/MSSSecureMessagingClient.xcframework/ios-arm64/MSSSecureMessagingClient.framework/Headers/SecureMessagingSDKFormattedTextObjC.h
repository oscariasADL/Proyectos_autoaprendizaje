#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

NS_REFINED_FOR_SWIFT
@interface SecureMessagingSDKFormattedTextObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Returns the text without any formatting.
 * @return the clear text
 */
@property(nonatomic, readonly) NSString *clearText;

/**
 * Returns the text with formatting.
 * @return the encoded text
 */
@property(nonatomic, readonly) NSString *encodedText;

/**
 * Returns if the text is in bold or not.
 * @return True if the text is in bold
 */
@property(nonatomic, readonly) BOOL isBold;

/**
 * Returns if the text is in italic or not.
 * @return True if the text is in italic
 */
@property(nonatomic, readonly) BOOL isItalic;

/**
 * Returns if the text is inversed or not.
 * @return True if the text is inversed
 */
@property(nonatomic, readonly) BOOL isInverse;

/**
 * Returns the color of the text.
 * <ul>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextColorDefault}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextColorRed}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextColorGreen}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextColorBlue}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextColorBlack}</li>
 * </ul>
 * @return The color of the text
 */
@property(nonatomic, readonly) char color;

/**
 * Returns the alignment of the text.
 * <ul>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentDefault}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentLeft}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentCenter}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextAlignmentRight}</li>
 * </ul>
 * @return The alignment of the text
 */
@property(nonatomic, readonly) char textAlignment;

/**
 * Returns the font table index of the text.
 * <ul>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexIso8859_15}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexKatakana}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexCentralAndEastEurope}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexGreek}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#formattedTextFontTableIndexTurkish}</li>
 * </ul>
 * @return The font table index of the text
 */
@property(nonatomic, readonly) NSInteger fontTableIndex;

@end

NS_ASSUME_NONNULL_END
