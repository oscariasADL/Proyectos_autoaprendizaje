
#ifndef TRANSACTIONDATA_H_
#define TRANSACTIONDATA_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else 
  #define EXPORT_DLL
#endif

#include <MSSSecureMessagingClient/FormattedText.h>
#include <MSSSecureMessagingClient/MultiFormattedText.h>
#include <MSSSecureMessagingClient/KeyValue.h>

#include <string>

namespace com
{
namespace vasco
{
namespace message
{
namespace client
{

class TransactionData
{
public:
	EXPORT_DLL TransactionData();
    EXPORT_DLL TransactionData(const TransactionData& other);
    EXPORT_DLL ~TransactionData();

	/**
	 * Returns The Encoded Message
	 * @return string message encoded
	 */
	EXPORT_DLL std::string getMessageEncoded() const;

	/**
	 * Set the encoded message
	 * @param messageEncoded The encoded message.
	 */
	EXPORT_DLL void setMessageEncoded(std::string messageEncoded);
	/**
	 * Set the version number
	 * @param appSecurityVersion int version number
	 */
	EXPORT_DLL void setAppSecurityVersion(int appSecurityVersion);
	/**
	 * Set the version number
	 * @param version int version number
	 */
	EXPORT_DLL void setVersion(int version);
	/**
	 * Set the Message type
	 * @param messageType message type.
	 */
	EXPORT_DLL void setMessageType(int messageType);
	/**
	 * Set the Crypto index.
	 * @param cryptoIndex Crypto index.
	 */
	EXPORT_DLL void setCryptoIndex(int cryptoIndex);
	/**
	 * Set The Template number
	 * @param templateNumber number
      @deprecated this property will be removed in future version
	 */
    __deprecated_msg("this property will be removed in future version")
	EXPORT_DLL void setTemplateNumber(int templateNumber);
	/**
	 * Set the Encoding type
	 * @param encodingType Encoding type
	 */
	EXPORT_DLL void setEncodingType(int encodingType);
	/**
	 * Set the show Mac option.
	 * @param showMAC bool to enable / disable option.
	 */
	EXPORT_DLL void setShowMAC(bool showMAC);
	/**
	 * Set The show warning option
	 * @param showWarning bool to enable / disable option.
	 */
	EXPORT_DLL void setShowWarning(bool showWarning);
	/**
	 * Set the Ask approval option
	 * @param askApproval bool to enable / disable option.
	 */
	EXPORT_DLL void setAskApproval(bool askApproval);
	/**
	 * Set the Ask pin option
	 * @param askPIN bool to enable / disable option.
	 */
	EXPORT_DLL void setAskPIN(bool askPIN);
	/**
	 * Set the Show Data option
	 * @param showData bool to enable / disable option.
	 */
	EXPORT_DLL void setShowData(bool showData);
	/**
	 * Set Font table index
	 * @param fontTableIndex font table index
	 */
	EXPORT_DLL void setFontTableIndex(int fontTableIndex);
	/**
	 * Set the MultiFormattedFreeText
	 * @param multiFormattedFreeText MultiFormattedText free text
	 */
	EXPORT_DLL void setMultiFormattedFreeText(model::MultiFormattedText multiFormattedFreeText);
	/**
	 * Set the FreeText
	 * @param freeText FormattedText free text
	 */
	EXPORT_DLL void setFreeText(model::FormattedText freeText);
	/**
	 * Set the Title
	 * @param title FormattedText title
	 */
	EXPORT_DLL void setTitle(model::FormattedText title);
	/**
	 * Set the Challenge
	 * @param challenge The formatted text challenge
	 */
	EXPORT_DLL void setChallenge(model::FormattedText challenge);
	/**
	 * Set the associative Array of key/value
	 * @param keyValueArray An array of KeyValue types
	 * @param size set the size (c array)
	 */
	EXPORT_DLL void setKeyValueArray(model::KeyValue* keyValueArray , unsigned int size);
	/**
	 * Set whether or not a hidden field is contained
	 * @param containsHiddenField bool indicating whether or not a hidden field is contained
	 */
	EXPORT_DLL void setContainsHiddenField(bool containsHiddenField);
	/**
	 * Set the hidden field
	 * @param hiddenField An array of bytes representing the hidden field
	 * @param size set the size (c array)
	 */
    EXPORT_DLL void setHiddenField(char* hiddenField, unsigned int size);


	/**
	 * Returns the Crypto application index.
	 * @return The Crypto application index.
	 */
	EXPORT_DLL int getCryptoIndex() const;

	/**
	 * Returns the showMAC bool.
	 * @return The showMAC bool.
	 */
	EXPORT_DLL bool isShowMAC() const;

	/**
	 * Returns the showWarning bool.
	 * @return The showWarning bool.
	 */
	EXPORT_DLL bool isShowWarning() const;
	/**
	 * Returns the askApproval bool.
	 * @return The askApproval bool.
	 */
	EXPORT_DLL bool isAskApproval() const;

	/**
	 * Returns the askPIN bool.
	 * @return The askPIN bool.
	 */
	EXPORT_DLL bool isAskPIN() const;
	/**
	 * Returns the showData bool.
	 * @return The showData bool.
	 */
	EXPORT_DLL bool isShowData() const;

	/**
	 * Returns the Template number.
	 * @return The Template Number.
     * @deprecated this property will be removed in future version
	 */
    __deprecated_msg("this property will be removed in future version")
	EXPORT_DLL int getTemplateNumber() const;

	/**
	 * Returns the Font table index.
	 * @return The Font table index.
	 */
	EXPORT_DLL int getFontTableIndex() const;

	/**
	 * Returns the minimum application security version.
	 * @return the minimum application security version.
	 */
	EXPORT_DLL int getAppSecurityVersion() const;

	/**
	 * Returns the version of the Transaction Request message.
	 * @return the version of the Transaction Request message.
	 */
	EXPORT_DLL int getVersion() const;

	/**
	 * Returns the type of the Transaction Request message.
	 * <ul>
	 *  <li>{@link com::vasco::message::constants::MESSAGE_TYPE_CHALLENGE}</li>
	 *  <li>{@link com::vasco::message::constants::MESSAGE_TYPE_FREE_TEXT}</li>
	 *  <li>{@link com::vasco::message::constants::MESSAGE_TYPE_TRANSACTION}</li>
	 * </ul>
	 * @return the type of the Transaction Request message.
	 */
	EXPORT_DLL int getMessageType() const;

	/**
	 * Returns the encoding type.
	 * @return The encoding type.
	 */
	EXPORT_DLL int getEncodingType() const;

	/**
	 * Returns the multi formatted free text as a {@link com::vasco::message::model::MultiFormattedText}
	 * @return The multi formatted free text (null if the parsed message is not a multi formatted free text).
	 */
	EXPORT_DLL model::MultiFormattedText* getMultiFormattedFreeText() const;

	/**
	 * Returns the free text as a {@link com::vasco::message::model::FormattedText}
	 * @return The freetext (empty if the parsed message is not a freetext transaction).
	 */
	EXPORT_DLL model::FormattedText getFreeText() const;

	/**
	 * Returns the title as a {@link com::vasco::message::model::FormattedText}
	 * @return The title (empty if the parsed message  is not a challenge or a signature transaction).
	 */
	EXPORT_DLL model::FormattedText getTitle() const;

	/**
	 * Returns the challenge as a {@link com::vasco::message::model::FormattedText}
	 * @return The challenge (empty if the parsed message is not a challenge transaction).
	 */
	EXPORT_DLL model::FormattedText getChallenge() const;

	/**
	 * Returns the key/value array as an array of {@link com::vasco::message::model::KeyValue}
	 * @param size the array size by reference to update the size
	 * @return The key/value array (null if the parsed message  is not a signature transaction).
	 */
	EXPORT_DLL model::KeyValue* getKeyValueArray(int &size) const;

	 /**
     * Returns true if the parsed message contains a hidden field, false otherwise
     * @return true if the parsed message contains a hidden field, false otherwise
     */
    EXPORT_DLL bool containsHiddenField() const;

    /**
     * Returns the hidden field as a byte array, if any.
     * @param size the array size by reference to update the size
     * @return The hidden field as a byte array (null if the parsed message does not contain any hidden field)
     */
    EXPORT_DLL char* getHiddenField(int &size) const;

private :

	int appSecurityVersion;

	int version;

	int messageType;

	int cryptoIndex;

	int templateNumber;

	int encodingType;

	bool showMAC;

	bool showWarning;

	bool askApproval;

	bool askPIN;

	bool showData;

	int fontTableIndex;

    std::string messageEncoded;

    model::MultiFormattedText* multiFormattedFreeText;

    model::FormattedText freeText;

    model::FormattedText title;

    model::FormattedText challenge;

    model::KeyValue* keyValueArray;

	int keyValuearraySize;

	bool isHiddenField;

    char* hiddenField;

    int hiddenFieldSize;

};

} /* namespace client */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* TRANSACTIONDATA_H_ */
