
#ifndef SECUREMESSAGINGSDKEXCEPTION_H_
#define SECUREMESSAGINGSDKEXCEPTION_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else 
  #define EXPORT_DLL
#endif

#include <exception>

namespace com
{
namespace vasco
{
namespace message
{
namespace exception
{

class SecureMessagingSDKException: public std::exception
{

public:
	/**
	 * Constructs a new DeviceBindingSDKException.
	 * @param errorCode The error code. See {@link com::vasco::message::constants::SecureMessagingSDKErrorCodes} for more details.
	 */
	EXPORT_DLL explicit SecureMessagingSDKException(int errorCode);
	EXPORT_DLL SecureMessagingSDKException(int errorCode , std::exception e);

	/**
	 * Gets the error code
	 * @return The error code
	 */
	EXPORT_DLL int getErrorCode();

	/**
	 * Gets the cause
	 * @return The underlying thrown exception
	 */
	EXPORT_DLL std::exception getCause();

private:

	/** Error code */
	int errorCode;

	/** Embedded exception */
	std::exception e;

};

} /* namespace exception */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* SECUREMESSAGINGSDKEXCEPTION_H_ */
