
#ifndef SECUREMESSAGINGSDKERRORCODES_H_
#define SECUREMESSAGINGSDKERRORCODES_H_

#if defined(__GNUC__) || defined(__clang__)
#define DEPRECATED __attribute__((deprecated))
#elif defined(_MSC_VER)
#define DEPRECATED __declspec(deprecated)
#else
#pragma message("WARNING: You need to implement DEPRECATED for this compiler")
#define DEPRECATED
#endif

namespace com
{
namespace vasco
{
namespace message
{
namespace constants
{

/**
 * An internal error occurred, the return code value is {@value com::vasco::message::constants::INTERNAL_ERROR}.
 */
static const int INTERNAL_ERROR = -4800;

/**
 * The serial number length is null, the return code value is {@value com::vasco::message::constants::SERIAL_NUMBER_NULL_OR_EMPTY}.
 */
static const int SERIAL_NUMBER_NULL_OR_EMPTY = -4801;

/**
 * The serial number length is incorrect, the return code value is {@value com::vasco::message::constants::SERIAL_NUMBER_INCORRECT_LENGTH}.
 * The serial number must be 10 characters.
 */
static const int SERIAL_NUMBER_INCORRECT_LENGTH = -4802;

/**
 * The serial number format is incorrect, the return code value is {@value com::vasco::message::constants::SERIAL_NUMBER_INCORRECT_FORMAT}.
 * The serial number must be alphanumeric.
 */
static const int SERIAL_NUMBER_INCORRECT_FORMAT = -4803;

/**
 * The activation code is empty or null, the return code value is {@value com::vasco::message::constants::ACTIVATION_CODE_NULL_OR_EMPTY}.
 */
static const int ACTIVATION_CODE_NULL_OR_EMPTY = -4804;

/**
 * The activation code length is incorrect, the return code value is {@value com::vasco::message::constants::ACTIVATION_CODE_INCORRECT_LENGTH}.
 * The activation code must be 16, 17, 20, 21, 32, 33, 40 or 41 characters.
 */
static const int ACTIVATION_CODE_INCORRECT_LENGTH = -4805;

/**
 * The activation code format is incorrect, the return code value is
 * {@value com::vasco::message::constants::ACTIVATION_CODE_INCORRECT_FORMAT}. If activation code length is
 * 16, 17, 32 or 33, it must be hexadecimal, otherwise it must be decimal.
 */
static const int ACTIVATION_CODE_INCORRECT_FORMAT = -4806;

/**
 * The event reactivation counter is too long, the return code value is
 * {@value com::vasco::message::constants::ERC_TOO_LONG}. Maximum length is 91 characters.
 */
static const int ERC_TOO_LONG = -4807;

/**
 * The event reactivation counter format is incorrect, the return code value is {@value com::vasco::message::constants::ERC_INCORRECT_FORMAT}.
 * It must be hexadecimal if the activation code is hexadecimal, otherwise it must be decimal.
 */
static const int ERC_INCORRECT_FORMAT = -4808;

/**
 * The user identifier is too long, the return code value is {@value com::vasco::message::constants::USER_IDENTIFIER_TOO_LONG}.
 * Maximum length is 40 characters.
 */
static const int USER_IDENTIFIER_TOO_LONG = -4809;

/**
 * The challenge is too long, the return code value is {@value com::vasco::message::constants::CHALLENGE_TOO_LONG}. Maximum length is 16 characters.
 */
static const int CHALLENGE_TOO_LONG = -4810;

/**
 * The challenge format is incorrect, the return code value is {@value com::vasco::message::constants::CHALLENGE_INCORRECT_FORMAT}.
 * The challenge must be hexadecimal.
 */
static const int CHALLENGE_INCORRECT_FORMAT = -4811;

/**
 * The challenge is null, the return code value is {@value com::vasco::message::constants::CHALLENGE_NULL}.
 */
static const int CHALLENGE_NULL = -4812;

/**
 * The dataFields array is empty or null, the return code value is {@value com::vasco::message::constants::DATA_FIELDS_ARRAY_NULL}.
 */
static const int DATA_FIELDS_ARRAY_NULL = -4813;

/**
 * The number of dataFields is invalid, the return code value is {@value com::vasco::message::constants::DATA_FIELDS_NUMBER_INVALID}.
 * Maximum number is 8 dataFields.
 */
static const int DATA_FIELDS_NUMBER_INVALID = -4814;

/**
 * One of the dataFields is null or empty, the return code value is {@value com::vasco::message::constants::DATA_FIELD_NULL}.
 */
static const int DATA_FIELD_NULL = -4815;

/**
 * One of the dataField has an incorrect length, the return code value is {@value com::vasco::message::constants::DATA_FIELD_INCORRECT_LENGTH}.
 * Datafield must be 16 characters maximum.
 */
static const int DATA_FIELD_INCORRECT_LENGTH = -4816;

/**
 * One of the dataField contains an incorrect character, the return code value is {@value com::vasco::message::constants::DATA_FIELD_CHARACTER_INVALID}.
 * Authorized characters are <i>0-9 A-Z %&'()*+,-./:;<=>?_</i>.
 */
static const int DATA_FIELD_CHARACTER_INVALID = -4817;

/**
 * Crypto application index is invalid, the return code value is {@value com::vasco::message::constants::CRYPTO_APPLICATION_INDEX_INVALID}.
 * Crypto application index must be between 1 and 8.
 */
static const int CRYPTO_APPLICATION_INDEX_INVALID = -4818;

/**
 * Template number is invalid, the return code value is {@value com::vasco::message::constants::TEMPLATE_NUMBER_INVALID}.
 * Template number must be between 0 and 15.
 */
static const int TEMPLATE_NUMBER_INVALID = -4819;

/**
 * Font table index is invalid, the return code value is {@value com::vasco::message::constants::FONT_TABLE_INDEX_INVALID}.
 * Font table index must be between 0 and 3.
 * Font table index must be included in font tables indexes mapping (set with #setCustomFontTablesIndexes method).
 * If mapping was not set then available font tables indexes are:
 * <ul>
 *   <li>{@link SecureMessagingSDKConstants#FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15}</li>
 *   <li>{@link SecureMessagingSDKConstants#FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA}</li>
 *   <li>{@link SecureMessagingSDKConstants#FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE}</li>
 *   <li>{@link SecureMessagingSDKConstants#FORMATTED_TEXT_FONT_TABLE_INDEX_GREEK}</li>
 * </ul>
 */
static const int FONT_TABLE_INDEX_INVALID = -4820;

/**
 * @deprecated
 *
 * Font table index is not supported, the return code value is {@value com::vasco::message::constants::FONT_TABLE_INDEX_NOT_SUPPORTED}.
 * This error code is not used anymore and is there for backward compatibility.
 */
DEPRECATED static const int FONT_TABLE_INDEX_NOT_SUPPORTED = -4821;

/**
 * The title is null, the return code value is {@value com::vasco::message::constants::TITLE_NULL}.
 */
static const int TITLE_NULL = -4822;

/**
 * The array of key/value is null, the return code value is {@value com::vasco::message::constants::KEYVALUE_ARRAY_NULL}.
 */
static const int KEYVALUE_ARRAY_NULL = -4823;

/**
 * The key/value object is null, the return code value is {@value com::vasco::message::constants::KEYVALUE_NULL}.
 */
static const int KEYVALUE_NULL = -4824;

/**
 * The key is null, the return code value is {@value com::vasco::message::constants::KEY_NULL}.
 */
static const int KEY_NULL = -4825;

/**
 * The value is null, the return code value is {@value com::vasco::message::constants::VALUE_NULL}.
 */
static const int VALUE_NULL = -4826;

/**
 * The freetext is null, the return code value is {@value com::vasco::message::constants::FREETEXT_NULL}.
 */
static const int FREETEXT_NULL = -4827;

/**
 * The minimum app security version is invalid, the return code value is {@value com::vasco::message::constants::MINIMUM_APP_SECURITY_VERSION_INVALID}.
 */
static const int MINIMUM_APP_SECURITY_VERSION_INVALID = -4828;
/**
 * The registration identifier format is incorrect, the return code value is {@value com::vasco::message::constants::REGISTRATION_IDENTIFIER_INCORRECT_FORMAT}.
 * The registration identifier must be alphanumeric.
 */
static const int REGISTRATION_IDENTIFIER_INCORRECT_FORMAT = -4829;

/**
 * The registration identifier is too long, the return code value is {@value com::vasco::message::constants::REGISTRATION_IDENTIFIER_TOO_LONG}.
 * Maximum length is 40 characters.
 */
static const int REGISTRATION_IDENTIFIER_TOO_LONG = -4830;

/**
 * The authorization code format is incorrect, the return code value is {@value com::vasco::message::constants::AUTHORIZATION_CODE_INCORRECT_FORMAT}.
 * The authorization code must be alphanumeric and/or can contain some authorized characters (% & ' ( ) * + , - . / : ; < = > ? _ # $ @ [ ] ^ ` |  )
 */
static const int AUTHORIZATION_CODE_INCORRECT_FORMAT = -4831;

/**
 * The authorization code is too long, the return code value is {@value com::vasco::message::constants::AUTHORIZATION_CODE_TOO_LONG}.
 * Maximum length is 40 characters.
 */
static const int AUTHORIZATION_CODE_TOO_LONG = -4832;

/**
 * The credentials message is empty or null, the return code value is {@value com::vasco::message::constants::CREDENTIALS_MESSAGE_NULL_OR_EMPTY}.
 */
static const int CREDENTIALS_MESSAGE_NULL_OR_EMPTY = -4833;

/**
 * The credentials message is invalid, the return code value is {@value com::vasco::message::constants::CREDENTIALS_MESSAGE_INVALID}.
 */
static const int CREDENTIALS_MESSAGE_INVALID = -4834;

/**
 * The activation password format is incorrect, the return code value is {@value com::vasco::message::constants::ACTIVATION_PASSWORD_INCORRECT_FORMAT}.
 * The activation password must be alphanumeric.
 */
static const int ACTIVATION_PASSWORD_INCORRECT_FORMAT = -4835;

/**
 * The activation password is too long, the return code value is {@value com::vasco::message::constants::ACTIVATION_PASSWORD_TOO_LONG}.
 * Maximum length is 40 characters.
 */
static const int ACTIVATION_PASSWORD_TOO_LONG = -4836;

/**
 * The user identifier format is incorrect, the return code value is {@value com::vasco::message::constants::USER_IDENTIFIER_INCORRECT_FORMAT}.
 * The user identifier must be alphanumeric.
 */
static const int USER_IDENTIFIER_INCORRECT_FORMAT = -4837;

/**
 * Formatted text alignment is invalid, the return code value is {@value com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID}.
 * Formatted text alignment must be
 * {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT}, {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT},
 * {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER}, {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT}.
 */
static const int FORMATTED_TEXT_ALIGNMENT_INVALID = -4838;

/**
 * Formatted text color is invalid, the return code value is {@value com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID}.
 * Formatted text color must be {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_DEFAULT},
 * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_RED}, {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_GREEN},
 * {@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLUE}, l{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_BLACK}.
 */
static const int FORMATTED_TEXT_COLOR_INVALID = -4839;

/**
 * The message body is invalid, the return code value is {@value com::vasco::message::constants::MESSAGE_BODY_INVALID}.
 */
static const int MESSAGE_BODY_INVALID = -4840;

/**
 * The message body is empty or null, the return code value is {@value com::vasco::message::constants::MESSAGE_BODY_NULL_OR_EMPTY}.
 */
static const int MESSAGE_BODY_NULL_OR_EMPTY = -4841;

/**
 * The message body is not an hexadecimal value, the return code value is {@value com::vasco::message::constants::MESSAGE_BODY_INCORRECT_FORMAT}.
 */
static const int MESSAGE_BODY_INCORRECT_FORMAT = -4842;

/**
 * The message body length is not even, the return code value is {@value com::vasco::message::constants::MESSAGE_BODY_LENGTH_NOT_EVEN}.
 */
static const int MESSAGE_BODY_LENGTH_NOT_EVEN = -4843;

/**
 * The message body length is too short, the return code value is {@value com::vasco::message::constants::MESSAGE_BODY_TOO_SHORT}.
 */
static const int MESSAGE_BODY_TOO_SHORT = -4844;

/**
 * The message body length is too long (the message body length cannot exceed {@link com::vasco::message::constants::MESSAGE_BODY_MAXIMUM_LENGTH}), the return code value is {@value com::vasco::message::constants::MESSAGE_BODY_TOO_LONG}.
 */
static const int MESSAGE_BODY_TOO_LONG = -4845;

/**
 * A character is not supported by the current font table, the return code value is {@link com::vasco::message::constants::FONT_TABLE_UNSUPPORTED_CHARACTER}.
 */
static const int FONT_TABLE_UNSUPPORTED_CHARACTER = -4861;

/**
 * The formatted text list is null or empty, the return code value is {@value com::vasco::message::constants::FORMATTED_TEXTS_NULL_OR_EMPTY}.
 */
static const int FORMATTED_TEXTS_NULL_OR_EMPTY = -4864;

/**
 * The clear text of formatted text is null or empty, the return code value is {@value com::vasco::message::constants::FORMATTED_TEXT_CLEAR_TEXT_NULL_OR_EMPTY}.
 */
static const int FORMATTED_TEXT_CLEAR_TEXT_NULL_OR_EMPTY = -4865;

/**
 * The font table indexes provided in incorrect order, the return code value is {@value com::vasco::message::constants::FONT_TABLE_INDEX_INVALID_MAPPING_ORDER}.
 */
static const int FONT_TABLE_INDEX_INVALID_MAPPING_ORDER = -4866;

/**
 * All provided font table indexes are empty, there should be at least one correct font table index provided, the return code value is {@value com::vasco::message::constants::FONT_TABLE_INDEXES_EMPTY_MAPPING}.
 */
static const int FONT_TABLE_INDEXES_EMPTY_MAPPING = -4867;

} /* namespace constants */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* SECUREMESSAGINGSDKERRORCODES_H_ */
