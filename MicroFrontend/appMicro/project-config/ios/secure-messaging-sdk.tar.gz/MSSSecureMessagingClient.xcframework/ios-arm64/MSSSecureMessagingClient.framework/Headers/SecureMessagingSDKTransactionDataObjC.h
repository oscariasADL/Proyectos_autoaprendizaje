#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class SecureMessagingSDKFormattedTextObjC;
@class SecureMessagingSDKMultiFormattedTextObjC;
@class SecureMessagingSDKKeyValueObjC;

NS_REFINED_FOR_SWIFT
@interface SecureMessagingSDKTransactionDataObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Returns the minimum application security version.
 * @return the minimum application security version.
 */
@property(nonatomic, readonly) NSInteger appSecurityVersion;

/**
 * Returns the version of the Transaction Request message.
 * @return the version of the Transaction Request message.
 */
@property(nonatomic, readonly) NSInteger version;

/**
 * Returns the type of the Transaction Request message.
 * <ul>
 *  <li>{@link SecureMessagingSDKConstantsObjC#messageTypeChallenge}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#messageTypeFreeText}</li>
 *  <li>{@link SecureMessagingSDKConstantsObjC#messageTypeTransaction}</li>
 * </ul>
 * @return the type of the Transaction Request message.
 */
@property(nonatomic, readonly) NSInteger messageType;

/**
 * Returns the Crypto application index.
 * @return The Crypto application index.
 */
@property(nonatomic, readonly) NSInteger cryptoIndex;

/**
 * Returns the Template number.
 * @return The Template Number.
 * @deprecated this property will be removed in future version
 */
@property(nonatomic, readonly) NSInteger templateNumber DEPRECATED_MSG_ATTRIBUTE("this property will be removed in future version");

/**
 * Returns the encoding type.
 * @return The encoding type.
 */
@property(nonatomic, readonly) NSInteger encodingType;

/**
 * Returns the showMAC bool.
 * @return The showMAC bool.
 */
@property(nonatomic, readonly) BOOL showMAC;

/**
 * Returns the showWarning bool.
 * @return The showWarning bool.
 */
@property(nonatomic, readonly) BOOL showWarning;

/**
 * Returns the askApproval bool.
 * @return The askApproval bool.
 */
@property(nonatomic, readonly) BOOL askApproval;

/**
 * Returns the askPIN bool.
 * @return The askPIN bool.
 */
@property(nonatomic, readonly) BOOL askPIN;

/**
 * Returns the askPIN bool.
 * @return The askPIN bool.
 */
@property(nonatomic, readonly) BOOL showData;

/**
 * Returns the Font table index.
 * @return The Font table index.
 */
@property(nonatomic, readonly) NSInteger fontTableIndex;

/**
 * Returns The Encoded Message
 * @return string message encoded
 */
@property(nonatomic, readonly) NSString *messageEncoded;

/**
 * Returns the multi formatted free text as a {@link SecureMessagingSDKMultiFormattedTextObjC}
 * @return The multi formatted free text (null if the parsed message is not a multi formatted free text).
 */
@property(nonatomic, nullable, readonly) SecureMessagingSDKMultiFormattedTextObjC *multiFormattedFreeText;

/**
 * Returns the free text as a {@link SecureMessagingSDKFormattedTextObjC}
 * @return The freetext (empty if the parsed message is not a freetext transaction).
 */
@property(nonatomic, nullable, readonly) SecureMessagingSDKFormattedTextObjC *freeText;

/**
 * Returns the title as a {@link SecureMessagingSDKFormattedTextObjC}
 * @return The title (empty if the parsed message  is not a challenge or a signature transaction).
 */
@property(nonatomic, nullable, readonly) SecureMessagingSDKFormattedTextObjC *title;

/**
 * Returns the challenge as a {@link SecureMessagingSDKFormattedTextObjC}
 * @return The challenge (empty if the parsed message is not a challenge transaction).
 */
@property(nonatomic, nullable, readonly) SecureMessagingSDKFormattedTextObjC *challenge;

/**
 * Returns the key/value array as an array of {@link SecureMessagingSDKKeyValueObjC}
 * @return The key/value array (null if the parsed message  is not a signature transaction).
 */
@property(nonatomic, readonly) NSArray<SecureMessagingSDKKeyValueObjC *> *keyValueArray;

/**
 * Returns true if the parsed message contains a hidden field, false otherwise
 * @return true if the parsed message contains a hidden field, false otherwise
 */
@property(nonatomic, readonly) BOOL containsHiddenField;

/**
 * Returns the hidden field as a byte array, if any.
 * @return The hidden field as a byte array (null if the parsed message does not contain any hidden field)
 */
@property(nonatomic, nullable, readonly) NSData *hiddenField;

@end

NS_ASSUME_NONNULL_END
