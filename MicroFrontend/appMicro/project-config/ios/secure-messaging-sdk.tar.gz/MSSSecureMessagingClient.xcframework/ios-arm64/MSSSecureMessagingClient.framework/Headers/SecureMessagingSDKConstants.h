
#ifndef SECUREMESSAGINGSDKCONSTANTS_H_
#define SECUREMESSAGINGSDKCONSTANTS_H_

#include <string>

namespace com
{
namespace vasco
{
namespace message
{
namespace constants
{

/**
 * The message is a transaction message
 */
static const int MESSAGE_TYPE_TRANSACTION = 0;

/**
 * The message is a challenge message
 */
static const int MESSAGE_TYPE_CHALLENGE = 1;

/**
 * The message is a free text message
 */
static const int MESSAGE_TYPE_FREE_TEXT = 2;

/**
 * The escape string used with formatting characters.
 */
static const std::string FORMAT_ESCAPE_CHARS = "%%";

/**
 * The default color used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_COLOR_DEFAULT = ' ';

/**
 * The red color used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_COLOR_RED = 'R';

/**
 * The green color used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_COLOR_GREEN = 'G';

/**
 * The blue color used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_COLOR_BLUE = 'B';

/**
 * The black color used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_COLOR_BLACK = 'K';

/**
 * The default text alignment used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_ALIGNMENT_DEFAULT = ' ';

/**
 * The left text alignment used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_ALIGNMENT_LEFT = 'L';

/**
 * The center text alignment used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_ALIGNMENT_CENTER = 'C';

/**
 * The right text alignment used for {@link FormattedText}.
 */
static const char FORMATTED_TEXT_ALIGNMENT_RIGHT = 'D';


/**
 * An empty font table used to indicate unused mapping.
 */
static const int FORMATTED_TEXT_FONT_TABLE_INDEX_EMPTY = -1;

/**
 * The font table index used for encoding a {@link FormattedText} in ISO-8859-15.
 */
static const int FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15 = 0;

/**
 * The font table index used for encoding a {@link FormattedText} with Katakana support.
 */
static const int FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA = 1;

/**
 * The font table index used for encoding a {@link FormattedText} with <a href="tables_central_and_east_europe.html" target="_blank">Central- and East-European languages</a> support.
 */
static const int FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE = 2;

/**
 * The font table index used for encoding a {@link FormattedText} with <a href="tables_greek.html" target="_blank">Greek language</a> support.
 */
static const int FORMATTED_TEXT_FONT_TABLE_INDEX_GREEK = 3;

/**
 * The font table index used for encoding a {@link FormattedText} with <a href="tables_turkish.html" target="_blank">Turkish language</a> support.
 */
static const int FORMATTED_TEXT_FONT_TABLE_INDEX_TURKISH = 4;

} /* namespace constants */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* SECUREMESSAGINGSDKCONSTANTS_H_ */
