
#ifndef MULTIFORMATTEDTEXT_H_
#define MULTIFORMATTEDTEXT_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else
  #define EXPORT_DLL
#endif

#include <MSSSecureMessagingClient/SecureMessagingSDKException.h>

#include <string>
#include <vector>

namespace com
{
namespace vasco
{
namespace message
{
namespace model
{

class FormattedText;

class MultiFormattedText {
private:
	static const int FIRST_ITEM_INDEX = 0;
	static const char PARSABLE_TEXT_ALIGNMENTS[];
	std::vector<FormattedText> formattedTextList;

    void init(const std::vector<FormattedText>& formattedTexts, char textAlignment, int fontTableIndex);

    /**
     * Forbidden default constructor
     */
	MultiFormattedText();

	bool isTextAlignmentParsable(char textAlignment) const;

public:
    /**
     * Copy constructor
     */
    EXPORT_DLL MultiFormattedText(const MultiFormattedText& other);

    EXPORT_DLL MultiFormattedText& operator=(const MultiFormattedText& other);

	/**
	 * Constructs a MultiFormattedText from a vector of formatted texts.
	 * Alignment and fontTableIndex values for each FormattedText object will be replaced with the ones passed in parameter.
	 *
	 * @param formattedTexts The vector of formatted text
	 * @param textAlignment  The text alignment of the text (See
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT})
	 * @param fontTableIndex The font table index used for encoding the text (See
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_GREEK},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_TURKISH})
	 * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
	 * <ul>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
	 *  <li>{@link com::vasco::message::constants::FONT_TABLE_INDEX_INVALID} if the font table index is invalid</li>
	 *  <li>{@link com::vasco::message::constants::FONT_TABLE_UNSUPPORTED_CHARACTER} if a character is not supported by the current font table</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXTS_NULL_OR_EMPTY} if the vector of formatted text is null or empty</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_CLEAR_TEXT_NULL_OR_EMPTY} if one of formatted text has null or empty clear text</li>
	 * </ul>
	 */
	EXPORT_DLL MultiFormattedText(const std::vector<FormattedText>& formattedTexts, char textAlignment, int fontTableIndex);

	/**
	 * Constructs a MultiFormattedText from a vector of formatted texts.
	 * Alignment value for each FormattedText object will be replaced with the one passed in parameter,
     * and fontTableIndex value with the default font table index (first one passed to #setCustomFontTablesIndexes
     * or ISO-8859-15 when custom available font tables indexes were not set).
	 *
	 * @param formattedTexts The vector of formatted text
	 * @param textAlignment  The text alignment of the text (See
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER},
	 *                       {@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT})
	 * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
	 * <ul>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
	 *  <li>{@link com::vasco::message::constants::FONT_TABLE_UNSUPPORTED_CHARACTER} if a character is not supported by the current font table</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXTS_NULL_OR_EMPTY} if the vector of formatted text is null or empty</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_CLEAR_TEXT_NULL_OR_EMPTY} if one of formatted text has null or empty clear text</li>
	 * </ul>
	 */
	EXPORT_DLL MultiFormattedText(const std::vector<FormattedText>& formattedTexts, char textAlignment);

	/**
	 * Returns the text without any formatting.
	 *
	 * @return the clear text
	 */
	EXPORT_DLL std::string getClearText() const;

	/**
	 * Returns the text with formatting.
	 *
	 * @return the encoded text
	 */
	EXPORT_DLL std::string getEncodedText() const;

	/**
	 * Returns the vector of formatted texts (See {@link com::vasco::message::model::FormattedText})
	 *
	 * @return vector of formatted texts
	 */
    EXPORT_DLL std::vector<FormattedText> getFormattedTextList() const;

	/**
	 * Returns the alignment of the text.
	 * <ul>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_DEFAULT}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_LEFT}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_CENTER}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_RIGHT}</li>
	 * </ul>
	 *
	 * @return The alignment of the text
	 */
	EXPORT_DLL char getTextAlignment() const;

	/**
	 * Returns the font table index of the text.
	 * <ul>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_ISO_8859_15}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_KATAKANA}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_CENTRAL_AND_EAST_EUROPE}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_GREEK}</li>
	 *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_FONT_TABLE_INDEX_TURKISH}</li>
	 * </ul>
	 *
	 * @return The font table index of the text
	 */
	EXPORT_DLL int getFontTableIndex() const;

    /**
     * Concatenates successive encoded formatted texts based on list of formatted texts in such a way that formatting
     * chars precede encoded text, for instance - the result of two bold formatted text ["11", "22"] is: "%%S11%%S22".
     *
     * @return The encoded texts with formatting chars
     */
	EXPORT_DLL std::string toString() const;

	/**
	 * Destructor
	 */
	EXPORT_DLL ~MultiFormattedText();



    /**
     * Parse an formatted text as a multi formatted text object.
     *
     * @param text The text to parse
     * @param fontTableIndex The font table index used for encoding the text
     * @return The multi formatted text object
     * @throws SecureMessagingSDKException If an exception occurred, the following error code can be thrown:
     * <ul>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_COLOR_INVALID} if the color is invalid</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_ALIGNMENT_INVALID} if the text alignment is invalid</li>
     *  <li>{@link com::vasco::message::constants::MESSAGE_BODY_INVALID} if the text is invalid</li>
     *  <li>{@link com::vasco::message::constants::FONT_TABLE_INDEX_INVALID} if the font table index is invalid</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXTS_NULL_OR_EMPTY} if the vector of formatted text is null or empty</li>
     *  <li>{@link com::vasco::message::constants::FORMATTED_TEXT_CLEAR_TEXT_NULL_OR_EMPTY} if one of formatted text has null or empty clear text</li>
     * </ul>
     */
    EXPORT_DLL static MultiFormattedText parseText(std::string text, int fontTableIndex);

    /**
     * Check if field is MultiFormattedText or not.
     *
     * @param field The text to parse
     * @return true if field should be parsed as MultiFormattedText
     */
    EXPORT_DLL static bool isMultiFormattedText(std::string field);
};

} /* namespace model */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* MULTIFORMATTEDTEXT_H_ */
