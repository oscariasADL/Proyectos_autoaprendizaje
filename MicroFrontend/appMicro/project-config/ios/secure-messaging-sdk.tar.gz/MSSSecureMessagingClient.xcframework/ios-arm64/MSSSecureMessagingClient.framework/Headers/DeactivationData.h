
#ifndef DEACTIVATION_H_
#define DEACTIVATION_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else 
  #define EXPORT_DLL
#endif

namespace com
{
namespace vasco
{
namespace message
{
namespace client
{

class DeactivationData
{
public:
	/**
	 * Constructor
	 */
	EXPORT_DLL DeactivationData();
	EXPORT_DLL ~DeactivationData();

private:

	int bodyType;
	int sequenceNumber;

public:

	/**
	 * Returns the bodyType of the Deactivation request message.
	 * @return the bodyType of the Deactivation Request message.
	 */
	int getBodyType();
	/**
	 * Returns the sequence number.
	 * @return the sequence number
	 */
	int getSequenceNumber();
	/**
	 * Sets the bodyType number.
	 */
	void setBodyType(int bodyType);
	/**
	 * Sets the sequence number.
	 */
	void setSequenceNumber(int sequenceNumber);


};

} /* namespace client */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* DEACTIVATION_H_ */
