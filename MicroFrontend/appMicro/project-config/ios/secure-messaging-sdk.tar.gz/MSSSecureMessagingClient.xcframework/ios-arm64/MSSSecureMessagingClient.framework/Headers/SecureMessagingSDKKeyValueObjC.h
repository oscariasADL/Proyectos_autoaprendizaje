#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class SecureMessagingSDKFormattedTextObjC;

NS_REFINED_FOR_SWIFT
@interface SecureMessagingSDKKeyValueObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * Returns the key.
 * @return The key
 */
@property(nonatomic, readonly) SecureMessagingSDKFormattedTextObjC *key;

/**
 * Returns the value.
 * @return The value
 */
@property(nonatomic, readonly) SecureMessagingSDKFormattedTextObjC *value;

@end

NS_ASSUME_NONNULL_END
