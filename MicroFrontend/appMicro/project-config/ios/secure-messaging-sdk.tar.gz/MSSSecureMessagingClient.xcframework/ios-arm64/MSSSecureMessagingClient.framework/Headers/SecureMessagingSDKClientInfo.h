#import <UIKit/UIKit.h>

//! Project version number for SecureMessagingSDKClient.
FOUNDATION_EXPORT double SecureMessagingSDKClientVersionNumber;

//! Project version string for SecureMessagingSDKClient.
FOUNDATION_EXPORT const unsigned char SecureMessagingSDKClientVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyFramework/PublicHeader.h>
