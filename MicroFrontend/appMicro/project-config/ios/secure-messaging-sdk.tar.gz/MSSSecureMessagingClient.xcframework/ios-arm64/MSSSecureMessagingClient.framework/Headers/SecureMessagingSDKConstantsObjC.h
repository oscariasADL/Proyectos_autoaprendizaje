#import <Foundation/Foundation.h>

NS_REFINED_FOR_SWIFT
@interface SecureMessagingSDKConstantsObjC : NSObject

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

/**
 * The message is a transaction message
 */
@property(class, nonatomic, readonly) NSInteger messageTypeTransaction;

/**
 * The message is a challenge message
 */
@property(class, nonatomic, readonly) NSInteger messageTypeChallenge;

/**
 * The message is a free text message
 */
@property(class, nonatomic, readonly) NSInteger messageTypeFreeText;

/**
 * The default color used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextColorDefault;

/**
 * The red color used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextColorRed;

/**
 * The green color used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextColorGreen;

/**
 * The blue color used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextColorBlue;

/**
 * The black color used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextColorBlack;

/**
 * The default text alignment used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextAlignmentDefault;

/**
 * The left text alignment used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextAlignmentLeft;

/**
 * The center text alignment used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextAlignmentCenter;

/**
 * The right text alignment used for {@link SecureMessagingSDKMultiFormattedTextObjC}.
 */
@property(class, nonatomic, readonly) char formattedTextAlignmentRight;

/**
 * An empty font table used to indicate unused mapping.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextFontTableIndexEmpty;

/**
 * The font table index used for encoding a {@link SecureMessagingSDKMultiFormattedTextObjC} in ISO-8859-15.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextFontTableIndexIso8859_15;

/**
 * The font table index used for encoding a {@link SecureMessagingSDKMultiFormattedTextObjC} with Katakana support.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextFontTableIndexKatakana;

/**
 * The font table index used for encoding a {@link SecureMessagingSDKMultiFormattedTextObjC} with <a href="tables_central_and_east_europe.html" target="_blank">Central- and East-European languages</a> support.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextFontTableIndexCentralAndEastEurope;

/**
 * The font table index used for encoding a {@link SecureMessagingSDKMultiFormattedTextObjC} with <a href="tables_greek.html" target="_blank">Greek language</a> support.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextFontTableIndexGreek;

/**
 * The font table index used for encoding a {@link SecureMessagingSDKMultiFormattedTextObjC} with <a href="tables_turkish.html" target="_blank">Turkish language</a> support.
 */
@property(class, nonatomic, readonly) NSInteger formattedTextFontTableIndexTurkish;

@end
