
#ifndef KEYVALUE_H_
#define KEYVALUE_H_

#if defined (_MSC_VER)
  /* Visual studio */
  #define EXPORT_DLL __declspec(dllexport)
#else 
  #define EXPORT_DLL
#endif

#include <MSSSecureMessagingClient/FormattedText.h>

#include <string>

namespace com
{
namespace vasco
{
namespace message
{
namespace model
{

class KeyValue
{

private:

    FormattedText key;
    FormattedText value;

    static const std::string SEPARATOR ;

public:

    /**
     * Default constructor.
     */
    EXPORT_DLL KeyValue();

    /**
     * Constructs a KeyValue object from a couple of key/value as {@link FormattedText}.
     * @param key The key as a {@link FormattedText}
     * @param value The value as a {@link FormattedText}
     */
    EXPORT_DLL KeyValue(FormattedText key, FormattedText value);
    
    /**
     * Copy constructor
     */
    EXPORT_DLL KeyValue(const KeyValue& other);
    
    EXPORT_DLL KeyValue& operator=(const KeyValue& other);
    
    /**
     * Destructor
     */
    EXPORT_DLL ~KeyValue();
    
    /**
     * Returns the KeyValue object as a string.
     */
    EXPORT_DLL std::string toString() ;

    /**
     * Returns the key.
     * @return The key
     */
    EXPORT_DLL FormattedText getKey() const;

    /**
     * Returns the value.
     * @return The value
     */
    EXPORT_DLL FormattedText getValue() const;
};

} /* namespace model */
} /* namespace message */
} /* namespace vasco */
} /* namespace com */

#endif /* KEYVALUE_H_ */
