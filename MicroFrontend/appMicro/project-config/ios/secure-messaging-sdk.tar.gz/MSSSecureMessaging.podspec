Pod::Spec.new do |spec|
    spec.name              = 'MSSSecureMessaging'
    spec.version           = '4.35.2'
    spec.summary           = 'Secure Messaging iOS SDK'
    spec.homepage          = 'https://www.onespan.com/'

    spec.author            = { 'Name' => 'OneSpan' }
    spec.license           = 'Proprietary'

    spec.platform          = :ios

    spec.source = { path: '.' }

    spec.ios.deployment_target = '13.0'
    spec.ios.vendored_frameworks = 'MSSSecureMessagingClient.xcframework'
end
