Pod::Spec.new do |spec|
    spec.name              = 'MSSDeviceBinding'
    spec.version           = '4.35.2'
    spec.summary           = 'Device Binding iOS SDK'
    spec.homepage          = 'https://www.onespan.com/'

    spec.author            = { 'Name' => 'OneSpan' }
    spec.license           = 'Proprietary'

    spec.platform          = :ios

    spec.source = { path: '.' }

    spec.ios.deployment_target = '13.0'
    spec.ios.vendored_frameworks = 'MSSDeviceBinding.xcframework'
end
