Pod::Spec.new do |spec|
    spec.name              = 'MSSSecureStorage'
    spec.version           = '4.35.2'
    spec.summary           = 'Digipass iOS SDK'
    spec.homepage          = 'https://www.onespan.com/'

    spec.author            = { 'Name' => 'OneSpan' }
    spec.license           = 'Proprietary'

    spec.platform          = :ios

    spec.source = { path: '.' }

    spec.ios.deployment_target = '13.0'
    spec.ios.vendored_frameworks = 'MSSSecureStorage.xcframework'
end
