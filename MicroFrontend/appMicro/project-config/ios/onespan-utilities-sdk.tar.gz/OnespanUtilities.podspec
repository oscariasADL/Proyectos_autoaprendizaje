
  Pod::Spec.new do |s|
    s.name = 'OnespanUtilities'
    s.version = '4.24.0'
    s.summary = 'Utilities of Onespan Mobile_Security_Suite_4.24.0'
    s.license = 'Proprietary'
    s.homepage = '.'
    s.author = { 'David Garzon' => 'david.garzon@avaldigitallabs.com' }
    s.source = { path: '.' }
    s.ios.vendored_frameworks = 'UtilitiesSDK.xcframework'
    s.ios.deployment_target  = '11.0'
  end
